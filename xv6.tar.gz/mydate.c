#include "types.h"
#include "user.h"
#include "date.h"

int main(int argc, char *argv[])
{
  struct rtcdate r;

  if (date(&r)) {
    printf(2, "date failed\n");
    exit();
  }

  printf(1, "Year: %d\n",r.year);
  printf(1, "Month: %d or %s\n", r.month, (r.month == 1 ? "January" :
                                          r.month == 2 ? "February" :
                                          r.month == 3 ? "March" :
                                          r.month == 4 ? "April" :
                                          r.month == 5 ? "May" :
                                          r.month == 6 ? "June" :
                                          r.month == 7 ? "July" :
                                          r.month == 8 ? "August" :
                                          r.month == 9 ? "September" :
                                          r.month == 10 ? "October" :
                                          r.month == 11 ? "November" :
                                                         "December"));
  printf(1, "Date: %d\n",r.day);
  printf(1, "Hour: %d\n",r.hour);
  printf(1, "Minute: %d\n",r.minute);
  printf(1, "Second: %d\n",r.second);
  exit();
}

